//
//  TableViewCell.swift
//  Streachy Header Effect Starter Project
//
//  Created by Abhishek Verma on 04/04/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var Profileimage: UIImageView!
    @IBOutlet weak var TutorialName: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
